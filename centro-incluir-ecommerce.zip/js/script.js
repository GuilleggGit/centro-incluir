document.addEventListener("DOMContentLoaded", () => {
  fetch("https://fakestoreapi.com/products")
    .then(res => res.json())
    .then(data => mostrarProductos(data));
});

function mostrarProductos(productos) {
  const contenedor = document.getElementById("lista-productos");
  productos.forEach(producto => {
    const card = document.createElement("div");
    card.className = "producto";
    card.innerHTML = `
      <img src="${producto.image}" alt="${producto.title}" />
      <h3>${producto.title}</h3>
      <p>${producto.description.substring(0, 100)}...</p>
      <p><strong>$${producto.price}</strong></p>
      <button onclick='agregarAlCarrito(${JSON.stringify({
        nombre: producto.title,
        precio: producto.price
      })})'>Agregar al carrito</button>
    `;
    contenedor.appendChild(card);
  });
}

function agregarAlCarrito(producto) {
  let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
  carrito.push(producto);
  localStorage.setItem("carrito", JSON.stringify(carrito));
  alert(`"${producto.nombre}" fue agregado al carrito.`);
}
