document.addEventListener("DOMContentLoaded", () => {
  fetch("js/productos.json")
    .then(response => response.json())
    .then(data => mostrarProductos(data))
    .catch(error => console.error("Error al cargar productos:", error));
});

function mostrarProductos(productos) {
  const contenedor = document.getElementById("lista-productos");
  productos.forEach(producto => {
    const card = document.createElement("div");
    card.className = "producto";
    card.innerHTML = `
      <img src="img/${producto.imagen}" alt="${producto.nombre}" />
      <h3>${producto.nombre}</h3>
      <p>${producto.descripcion}</p>
      <p><strong>$${producto.precio}</strong></p>
      <button onclick="agregarAlCarrito('${producto.nombre}')">Agregar al carrito</button>
    `;
    contenedor.appendChild(card);
  });
}

function agregarAlCarrito(nombre) {
  alert(`"${nombre}" fue agregado al carrito (simulado).`);
}
